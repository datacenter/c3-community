#!/bin/bash


echo "Image Created By Packer" >> /tmp/README.txt
