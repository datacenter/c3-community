sudo sed -i -- 's/:80/:9200/g' /etc/haproxy/haproxy.cfg
