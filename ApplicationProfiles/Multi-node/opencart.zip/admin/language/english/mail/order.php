<?php
// Text
$_['text_subject']      = '%s - Order Update %s';
$_['text_order']        = 'Order ID:';
$_['text_date_added']   = 'Date Ordered:';
$_['text_order_status'] = 'Your order has been updated to the following status:';
$_['text_comment']      = 'The comments for your order are:';
$_['text_link']         = 'To view your order click on the link below:';
$_['text_footer']       = 'Please reply to this email if you have any questions.';
?>